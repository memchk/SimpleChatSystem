#pragma once
#include <gsl/gsl>
#include <string>

namespace scs::shared {

using span = gsl::span<unsigned char>;
using const_span = gsl::span<const unsigned char>;

// CRC table calculation
constexpr std::array<uint16_t, 256> CalculateCRC16Table(
    uint16_t lsb_polynomial) {
  std::array<uint16_t, 256> crc_table{};
  for (uint16_t i = 0; i < 256; i++) {
    auto byte = i;
    for (auto bit = 0; bit < 8; bit++) {
      if (byte & 0x01) {
        byte >>= 1;
        byte ^= lsb_polynomial;
      } else {
        byte >>= 1;
      }
    }
    crc_table[i] = byte;
  }
  return crc_table;
}

const std::array<uint16_t, 256> CRC_16_CCITT_TABLE =
    CalculateCRC16Table(0x8408);
constexpr uint16_t CalculateCRC16CCITT(const_span data) {
  uint16_t crc = 0;
  for (auto &i : data) {
    auto idx = (crc ^ i) & 0xFF;
    crc = (crc >> 8) ^ CRC_16_CCITT_TABLE[idx];
  }

  return crc;
}

bool ParseString(std::string &str, const_span &data);
std::pair<bool, span> SerializeString(const std::string &str, span data);

class Packet {
 public:
  virtual bool ReadFromSpan(gsl::span<const unsigned char> &data) = 0;
  virtual bool Serialize(gsl::span<unsigned char> &data) const = 0;
  virtual unsigned char opcode() const = 0;
};

class HELOPacket final : public Packet {
 private:
  std::string user_name_;
  std::string init_channel_;

 public:
  HELOPacket() = default;
  HELOPacket(const std::string &user_name, const std::string &init_channel = "")
      : user_name_(user_name), init_channel_(init_channel) {}

  void set_user_name(const std::string &user_name) { user_name_ = user_name; }
  const std::string &user_name() const { return user_name_; }

  void set_init_channel(const std::string &init_channel) {
    init_channel_ = init_channel;
  }
  const std::string &init_channel() const { return init_channel_; }

  bool ReadFromSpan(gsl::span<const unsigned char> &data) override {
    if (ParseString(user_name_, data)) {
      ParseString(init_channel_, data);
      return true;
    }
    return false;
  }

  bool Serialize(gsl::span<unsigned char> &data) const override {
    auto [ok, data1] = SerializeString(user_name_, data);
    if(ok) {
      auto [_, data2] = SerializeString(user_name_, data1);
      (void)_;
      auto len = data.size() - data2.size();
      data = span(data.data(), len);
      return true;
    }

    return false;
  }

  unsigned char opcode() const { return 0x04; }
};

// class MSGPacket final : public Packet {
//  private:
//   std::string from_;
//   std::string msg_;

//  public:
//   MSGPacket() = default;
//   MSGPacket(const std::string &from, const std::string &msg_)
//       : from_(from), msg_(msg_) {}

//   void set_from(const std::string &from) { from_ = from; }
//   const std::string &from() const { return from_; }

//   void set_msg(const std::string &msg) { msg_ = msg; }
//   const std::string &msg() const { return msg_; }

//   bool ReadFromSpan(gsl::span<const unsigned char> &data) override {
//     if (ParseString(from_, data)) {
//       if(ParseString(msg_, data)) {
//         return true;
//       }
//     }
//     return false;
//   }

//   bool Serialize(std::ostream &os) const override {
//     if (SerializeString(from_, os)) {
//       if(SerializeString(msg_, os)) {
//         return true;
//       }
//     }
//     return false;
//   }

//   unsigned char opcode() const { return 0x08; }
// };

namespace {
template <unsigned char OpCode>
class NoDataPacketImpl final : public Packet {
  bool ReadFromSpan(gsl::span<unsigned char> _data) override { return true; };
  bool Serialize(gsl::span<unsigned char> &data) const override { return true; };

  unsigned char opcode() const override { return OpCode; }
};
}  // namespace

using ACKPacket = NoDataPacketImpl<0x00>;
using InvalidFCSPacket = NoDataPacketImpl<0x02>;

}  // namespace scs::shared
