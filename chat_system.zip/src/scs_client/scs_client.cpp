#include<arpa/inet.h>
#include<sys/socket.h>
#include <netdb.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <unistd.h>

#include "shared/Packet.hpp"

using namespace scs;
using namespace std::string_literals;

int main(int argc, char const *argv[])
{
    sockaddr_in server_addr;

    addrinfo hints;
    addrinfo *result;

    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;    /* Allow IPv4 or IPv6 */
    hints.ai_socktype = SOCK_STREAM; /* Datagram socket */

    getaddrinfo("localhost", "24343", &hints, &result);


    int socket_desc;

	if((socket_desc = socket(result->ai_family , result->ai_socktype , 0)) < 0)
    {
        std::cout << "socket" << std::endl;
        return -1;
    }

    if(connect(socket_desc, result->ai_addr, result->ai_addrlen) < 0)
    {
        perror("connect");
        return -1;
    }

    unsigned char buf[1024];
    gsl::span<unsigned char> buf_span {buf};

    shared::HELOPacket helo("memchk");
    helo.Serialize(buf_span);
    send(socket_desc, buf_span.data(), buf_span.size(), 0);

    shutdown(socket_desc, SHUT_RDWR);
    close(socket_desc);
}   