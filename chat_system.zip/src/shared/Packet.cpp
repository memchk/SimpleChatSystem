#include <limits>
#include "shared/Packet.hpp"

namespace scs::shared
{
    bool ParseString(std::string &str, const_span &data)
    {   
        if(data.size() > 4)
        {
            std::size_t length = data[0] | (data[1] << 8) | (data[2] << 16) | (data[3] << 24);
            if (length + 4 <= data.size())
            {
                auto str_data = data.subspan(4, length);
                data = data.subspan(length + 4);
                str = std::string(str_data.begin(), str_data.end());
                return true;
            }
        } 
        return false;
    }

    std::pair<bool, span> SerializeString(const std::string &str, span data)
    {
        if (str.empty()) {
            return std::make_pair(true, data);
        }
        if (str.size() > std::numeric_limits<unsigned int>::max())
        {
            return std::make_pair(false, data);
        }

        auto length = static_cast<unsigned int>(str.size());
        //FIXME: Make endian independent.
        *data.data() = length;
        std::copy(str.begin(), str.end(), data.subspan(sizeof(length)).begin());


        auto new_data = data.subspan(length + sizeof(length));
        return std::make_pair(true, new_data);
    }
} // namespace scs::shared
